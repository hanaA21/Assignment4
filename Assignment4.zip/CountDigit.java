package Assignments;

public class CountDigit {
    public static int countDigits(int n) {
        if (n < 10) {
            return 1;
        } else {
            return 1 + countDigits(n / 10);
        }
    }

    public static void main(String[] args) {
        int num = 12345;
        int digitCount = countDigits(num);
        System.out.println("Number of digits: " + digitCount);
    }
}

