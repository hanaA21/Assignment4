package Assignments;

public class ReverseDigit {
    public static void Reverse(int n) {
        if (n < 10) {
            System.out.println(n);
        } else {
            System.out.print(n % 10);
            Reverse(n / 10);
        }
    }

    public static void main(String[] args) {
        int num = 12345;
        Reverse(num);
    }
}

